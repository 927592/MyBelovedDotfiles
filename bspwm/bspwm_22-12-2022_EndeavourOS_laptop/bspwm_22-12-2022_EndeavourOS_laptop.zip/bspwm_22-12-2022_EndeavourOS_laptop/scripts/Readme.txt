If you want to use 2 Border on bspwm, you need to install wmutils.
after that you can put the borders file from the bin folder in this config
to /usr/bin or your PATH.

other script if usefull if you want a full feature of the rice. mostly dmenu script.
just copy and paste all the script into your PATH.
also don't forget to use "chmod +x scriptname" so it will be executable
